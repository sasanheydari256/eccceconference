export const Colors = {
  lightGrey: '#F0EFEF',
  MedionLightGrey: '#D5D5D5',
  Grey: 'grey',
};
